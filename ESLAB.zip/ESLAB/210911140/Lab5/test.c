#include<LPC17xx.h>
int main(){
	SystemInit();
	SystemCoreClockUpdate();
	LPC_PINCON->PINSEL0=0;
	LPC_GPIO0->FIODIR=0x10;
	LPC_GPIO0->FIOSET=1<<4;
}