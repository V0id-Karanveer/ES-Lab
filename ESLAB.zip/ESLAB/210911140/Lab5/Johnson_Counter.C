#include<LPC17xx.h>
int main(){
	long int x=0x1;
	int i,j;
	SystemInit();
	SystemCoreClockUpdate();
	LPC_PINCON->PINSEL0=0;
	LPC_GPIO0->FIODIR=0xF0;
	while(1){
		for(i=0;i<=3;i++){
			LPC_GPIO0->FIOSET=x<<(4-i-1)<<4;
			for(j=0;j<5000000;j++);
		}
		
		for(i=0;i<=3;i++){
			LPC_GPIO0->FIOCLR=x<<(4-i-1)<<4;
			for(j=0;j<5000000;j++);
		}
		
	}
}