#include<LPC17xx.h>
int main(){
	int i;
	SystemInit();
	SystemCoreClockUpdate();
	LPC_PINCON->PINSEL0=0;
	LPC_GPIO0->FIODIR=0xFF0;
	while(1){
		int x=0;
		LPC_GPIO0->FIOSET=x<<4;
		for(i=0; i<2000000; i++);
		LPC_GPIO0->FIOCLR=0xFF0;
	}
}