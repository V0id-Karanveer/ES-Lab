#include<LPC17xx.h>
int main(){
	long long int i;
	SystemInit();
	SystemCoreClockUpdate();
	LPC_PINCON->PINSEL0=0;
	LPC_GPIO0->FIODIR=0xFF0;
	while(1){
		LPC_GPIO0->FIOSET=0XFF<<4;
		for(i=0;i<2000000;i++);
		LPC_GPIO0->FIOCLR=0XFF<<4;
		for(i=0;i<2000000;i++);
	}
}