#include<LPC17xx.h>
int number=0,n;
int count = 0, i, j;
int seven_seg[]={0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};

 

void timer_init(){
	LPC_TIM0->TCR=0x2;
	LPC_TIM0->CTCR=0;
	LPC_TIM0->MCR=0x2;
	LPC_TIM0->EMR=0x20;
	LPC_TIM0->PR=2999;
	LPC_TIM0->TCR=0x1;
	LPC_TIM0->MR0=9999;
}

 

int main()
{
	SystemInit();
	SystemCoreClockUpdate();
	LPC_PINCON->PINSEL0=0;
	LPC_PINCON->PINSEL1=0;
	LPC_PINCON->PINSEL3=0;
	LPC_GPIO0->FIODIR=0xFF<<4;
	LPC_GPIO1->FIODIR=0xF<<23;
	timer_init();
	while(1)
	{
		n=number;
		for(i=0; i<4; i++){
			LPC_GPIO1->FIOPIN=i<<23;
			LPC_GPIO0->FIOPIN=seven_seg[n%10]<<4;
			n/=10;
			for(j=0; j<1000; j++);
		}
		if(LPC_TIM0->EMR&1)
		{
			LPC_TIM0->EMR=0x20;
			if(!(LPC_GPIO0->FIOPIN & 1<<21)){
				if(number==0)
				{
					number = 9999;
				}
				else number --;
			}
			else{
				if(number == 9999){
				number=0;
				}
				else number ++;
		}
	}
}
	return 0;
}