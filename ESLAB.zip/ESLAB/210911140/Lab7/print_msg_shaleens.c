#include <LPC17xx.h>
#include<stdio.h>
char temp, msg1;
unsigned int k, x;
unsigned int i=0, flag1, j;

 

void delay(int k)
{
	for (j=0; j<k; j++);
}

 

void port_write()
{
	LPC_GPIO0->FIOPIN=temp<<23;
	if (flag1==0)
	{
		LPC_GPIO0->FIOCLR=1<<27;
	}
	else
	{
		LPC_GPIO0->FIOSET=1<<27;
	}
	LPC_GPIO0->FIOSET=1<<28;
	delay(50);
	LPC_GPIO0->FIOCLR=1<<28;
	delay(100000);
}

 

void lcd_write()
{
	temp=(msg1>>4)&0x0F;
	port_write();
	if (!(flag1==0)&((msg1==0x20)||(msg1==0x30))){
		temp=msg1&0x0F;
		port_write();
	}
}

 

int main()
{

	char msg[]={" MIT"};

 

	int init_command[]={0x30, 0x30, 0x30, 0x20, 0x28, 0x80, 0x06, 0x0C, 0x01};
	SystemInit();
	SystemCoreClockUpdate();
	LPC_PINCON->PINSEL1=0;
	LPC_GPIO0->FIODIR=0xF<<23|1<<27|1<<28;
	flag1=0;
	for(i=0;i<9;i++)
	{
		msg1=init_command[i];
		lcd_write();
	}
	flag1=1;
	i=0;
while(msg[i]!='\0')
	{
		msg1 = msg[i];
		i++;
		if(i==16)
		{
			flag1=0;
			msg1=0xC0;
			lcd_write();
			flag1=1;
			i--;
			msg1=msg[i];
			i++;
		}
		lcd_write();
	}
	while(1);
}