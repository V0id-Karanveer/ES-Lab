#include<LPC17xx.h>

unsigned int temp1, temp2, flag1, i, j;
char message[]=" Hello helo ";

void port_write(){
	LPC_GPIO0->FIOPIN=temp2<<23;
	if (flag1==0)
	{
		LPC_GPIO0->FIOCLR=1<<27;
	}
	else
	{
		LPC_GPIO0->FIOSET=1<<27;
	}
	LPC_GPIO0->FIOSET=1<<28;
	for(j=0;j<50;j++);
	LPC_GPIO0->FIOCLR=1<<28;
	for(j=0;j<100000;j++);
}

void lcd_write(){
	temp2=(temp1>>4)&0x0F;
	port_write();
	//if(!(flag1==0 && (temp1==0x30 || temp1==0x20))){
		temp2=(temp1&0x0F);
		port_write();
	//}
}



int main()
{
	int commands[]={0x30,0x30,0x30,0x20,0x28,0x80,0x06,0x0C,0x01};
	SystemInit();
	SystemCoreClockUpdate();
	LPC_PINCON->PINSEL1=0;
	LPC_GPIO0->FIODIR=0xF<<23|1<<26|1<<27;
	flag1=0;
	for(i=0; i<=9; i++){
		temp1=commands[i];
		lcd_write();
	}
	flag1=1;
	for(i=0; message[i]!='\0'; i++)
	{
		if(i==16)
		{
			flag1=0;
			temp1=0xC0;
			lcd_write();
			flag1=1;
		}
		temp1=message[i];
		lcd_write();
	}
	while(1);
}